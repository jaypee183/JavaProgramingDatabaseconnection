import javax.swing.*;
import java.awt.*;

///  this is the page of the receipt after the order payment has been confirmed

public class ReceiptView extends JPanel {
    ReceiptView() {
        setBackground(Color.BLUE);
    }
}

public class productOrders {
    private final int number;
    private final String name;
    private final int quantity;
    private final int price;


    /**
     *
     * @param number
     * @param name
     * @param quantity
     * @param price
     *
     * {@link ProductObjects} but for transaction list,
     */

    productOrders(int number, String name, int quantity, int price) {
        this.number = number;
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }

    public int getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getPrice() {
        return price;
    }
}

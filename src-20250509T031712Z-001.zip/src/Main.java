import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * this inventory sales system is a shopping system where it stores and lets you purchase order
 *
 */

///  refer to DBoperations class to get an idea on how to implement a database
class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Window("Inventory System"));
    }
}

import javax.swing.*;
import java.awt.*;

public class GUIUpdateHandler {


    private static void refreshUI(Component parent) {
        parent.revalidate();
        parent.repaint();
    }

    /// Handles the GUI Update in the maincard2 or the shopping product catalog

    public static void renderUI(ProductObjects component, JPanel parent, Action actions) {
        switch (actions) {
            case ADD -> {
                parent.add(component);
                refreshUI(parent);
            }
            case DELETE -> {
                parent.remove(component);
                refreshUI(parent);
            }
        }
    }

    ///  handles the GUI Update in the order transaction in the maincard3
    ///
    public static void renderUI(productOrders component, JPanel parent)
    {

    }

    public static void buildProductPanel() {

    }

}

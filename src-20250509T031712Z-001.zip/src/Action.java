public enum Action {
    SEARCH, EDIT, ADD, DELETE;
}

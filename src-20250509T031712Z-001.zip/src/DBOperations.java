



import javax.swing.*;

/// this where the database manipulations happens
/// in theory it should handle all the database logic in all the program that is instructed
/// the order is that it should be handled first in the Database first then
/// then calls a method that handles parsing textfile into objects the
/// maps the all the object to the arrayList through retrieveAllDatabaseProduct()
///
/// then loops through the arraylist
/// for each element in the array, those component is added
/// then finally renders it in the page through renderUI()
/// this goes same for the Transaction orders too,
/// also handles logic like pricing and quantity
///
/// also the Database should have at least three textfiles preferably
/// one for account, secondly the product panels that is displayed in the shopping catalogue
/// finally the transaction orders, when you order, you create an object
///
/// regarding the transaction orders, duplicates should be avoided for example
/// Product 1 Quantity = 1;
/// Product 1 Quantity = 1;
///
/// it should be like this instead Product 1 Quantity = 2
///
/// It should handle cases like those.
///
/// HOWEVER IF YOU DO HAVE A BETTER WAY OF IMPLEMENTING A DATABASE, then implement that one instead

public final class DBOperations {
    public static void searchProcess() {

    }


    /// adds a new object to the database
    public static void addProcess(String name, double price, int quantity){

        System.out.println("FucK is this shit" + name);
        long id = System.currentTimeMillis();
        GUIUpdateHandler.renderUI(new ProductObjects(id, name, quantity, price), Utils.product, Action.ADD);
    }

    /// Updates the currently selected object to new state
    /// to do this simply call the retrieveAllDatabaseProduct then loop through it
    /// to find the ID if it matches, get all the name price, image quantity through their respective getter methods
    /// once update, search for the ID again then retrieve the ID dont delete it but simply assing them with new variables

    public static void editProcess(long ID, String name, double price, int quantity, Action actions) {

    }

    ///  removes the a specific targeted object from the database
    public static void deleteProcess(long id, Action actions) {

    }

    ///  retrieves a specific targetd information of a product
    public static void retrieveDatabaseProduct(int ID) {

    }

    /// handles to retrieve all parse the database textfile into an object
    public static void retrieveAllDatabaseProduct() {

    }

    /// gets all the total price of a product
    public static void getAllPriceOrder() {

    }
}

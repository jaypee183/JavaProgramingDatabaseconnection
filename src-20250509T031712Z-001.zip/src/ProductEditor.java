import javax.swing.*;

public class ProductEditor {
    ProductEditor(JButton btnAction, Action actions) {
        btnAction.addActionListener(e -> {
            switch (actions) {
                case SEARCH -> search();
                case ADD -> openDialogAdd();
            }
        });
    }

    ProductEditor(JButton btnAction, Action actions, long id) {
        btnAction.addActionListener(e -> {
            switch (actions) {
                case EDIT -> openDialogEdit(id);
                case DELETE -> openDialogDelete(id);
            }
        });
    }

    private void search() {

    }

    private void openDialogEdit(long id) {
        System.out.println(id);
        EditWindow s = new EditWindow();
    }

    private void openDialogAdd() {
        new AddWindow();
    }

    private void openDialogDelete(long id) {
       int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to remove this product from the display?", "Confirm Delete", JOptionPane.YES_NO_OPTION);

       if (result == JOptionPane.YES_OPTION) DBOperations.deleteProcess(id, Action.DELETE);
       else return;
    }
}

import javax.swing.*;


///  this is the homepage of the homepanel
public class Maincard1 extends JPanel {
    Maincard1() {
        setBackground(Utils.ACCENT_COLOR);

        JPanel homepage = new JPanel();
    }
}

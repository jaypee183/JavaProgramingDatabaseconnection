import javax.swing.*;
import java.awt.*;


///  the login panel
///
/// there should be a database for an account for this
/// but for now let us ignore that logic

public class LoginPanel extends JPanel {
    public LoginPanel(Window parent) {
        setBackground(Utils.BG_COLOR);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        JPanel loginForm = new JPanel(new GridBagLayout());
        loginForm.setPreferredSize(new Dimension(350, 300));
        loginForm.setBackground(new Color(40, 40, 40));
        loginForm.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        gbc.insets = new Insets(10, 0, 5, 0);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(Utils.FONT_PLAIN);
        userLabel.setForeground(Color.WHITE);
        loginForm.add(userLabel, gbc);

        gbc.gridy++;
        JTextField userField = new JTextField();
        styleInput(userField);
        loginForm.add(userField, gbc);

        gbc.gridy++;
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(Utils.FONT_PLAIN);
        passLabel.setForeground(Color.WHITE);
        loginForm.add(passLabel, gbc);

        gbc.gridy++;
        JPasswordField passwordField = new JPasswordField();
        passwordField.setEchoChar('•');
        styleInput(passwordField);
        loginForm.add(passwordField, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(15, 0, 0, 0);
        JButton loginBtn = new JButton("Login");
        loginBtn.setFocusPainted(false);
        loginBtn.setFont(Utils.FONT_PLAIN);
        loginBtn.setBackground(Utils.ACCENT_COLOR);
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setPreferredSize(new Dimension(0, 35));


        ///  THe logic for the log-in form is here
        
        loginBtn.addActionListener(e -> parent.showCard("Home"));
        loginForm.add(loginBtn, gbc);

        add(loginForm);
    }

    private void styleInput(JTextField field) {
        field.setPreferredSize(new Dimension(200, 30));
        field.setFont(Utils.FONT_PLAIN);
        field.setForeground(Utils.INPUT_FG);
        field.setBackground(Utils.INPUT_BG);
        field.setCaretColor(Color.WHITE);
        field.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
    }
}

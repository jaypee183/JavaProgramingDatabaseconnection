import javax.swing.*;


///  the panel that should display when the search event has been confirmed
/// should be displayed in the shopping catalog

public class SearchResponse extends JPanel {

}

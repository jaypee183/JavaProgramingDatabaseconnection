import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;


///  a global unified reusable variables, to avoid redundancy

public final class Utils {
    public static final Font FONT_PLAIN = new Font("SansSerif", Font.PLAIN, 14);
    public static final Font FONT_BOLD = new Font("SansSerif", Font.BOLD, 24);
    public static final Color BG_COLOR = new Color(30, 30, 30);
    public static final Color BG2_COLOR = new Color(40, 40, 41);
    public static final Color ACCENT_COLOR = new Color(70, 130, 180);
    public static final Color INPUT_BG = new Color(50, 50, 50);
    public static final Color INPUT_FG = Color.WHITE;

    public static JPanel product;

    //Database
    public static ArrayList<Object> dbList = new ArrayList<>();

    public static JPanel topBar() {
        JPanel topBar = new JPanel();
        topBar.setPreferredSize(new Dimension(200, 60));
        topBar.setLayout(new GridBagLayout());
        topBar.setBackground(Utils.BG_COLOR);
        return topBar;
    }

    public static JScrollPane mainContent(int width, int height) {
        Dimension size = new Dimension(width, height);

        JPanel panel = new JPanel();
        panel.setBackground(Utils.BG2_COLOR);
        panel.setPreferredSize(size);


        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(BG2_COLOR);

        return scrollPane;
    }

    public static JLabel setText(Font a, Color b, String text) {
        JLabel label = new JLabel(text);
        label.setFont(a);
        label.setForeground(b);
        return label;
    }


   // public static JPanel footerContent(int width, int height) {

   // }
}
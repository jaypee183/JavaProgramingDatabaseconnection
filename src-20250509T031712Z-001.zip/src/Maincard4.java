import javax.swing.*;
import java.awt.*;

/**
 * Not the main priority, just about some About us page
 */


public class Maincard4 extends JPanel {
  private static GridBagConstraints gbc = new GridBagConstraints();

  Maincard4() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        JPanel s = Utils.topBar();
        s.setLayout(new GridBagLayout());
        add(s);

        JScrollPane a = Utils.mainContent(200, 1500);
        add(a);
        a.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        navBar(s);

        JPanel content = (JPanel) a.getViewport().getView();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));


        JPanel panel1 = new JPanel();
        panel1.setMaximumSize(new Dimension(600, 50));
        panel1.setBackground(Utils.BG2_COLOR);
        content.add(panel1);
        panel1.add(Utils.setText(Utils.FONT_BOLD, Utils.INPUT_FG, "ABOUT US"));


        MembersPanel(content);
        information(content);


    }

    private void MembersPanel(JPanel a) {
      String[] names = {"Japhet Paul", "Charles Kevin", "Nathaniel Jade"};
      JPanel s = new JPanel();
      s.setPreferredSize(new Dimension(800, 260));
      s.setMaximumSize(new Dimension(1500, 200));
      s.setBackground(Utils.BG2_COLOR);
      s.setLayout(new GridBagLayout());
      a.add(s);

      for (int i = 0; i < 3; i++) {
          gbc.gridx = i;
          gbc.gridy = 0;
          gbc.weightx = 1;
          s.add(createMemberPanel(), gbc);

          JLabel label = Utils.setText(Utils.FONT_BOLD, Utils.INPUT_FG, names[i]);
          gbc.gridy = 1;
          gbc.gridx = i;
          s.add(label, gbc);
      }
    }

    private void information (JPanel a) {
      JPanel textBox = new JPanel();
      textBox.setPreferredSize(new Dimension(400, 300));
      textBox.setMaximumSize(new Dimension(500, 300));
      textBox.setBackground(Utils.BG2_COLOR);
      a.add(textBox);

        JLabel label = new JLabel("<html><body style='width: 200px;'>This is a long text that should wrap within the specified width.</body></html>");
      JLabel b = Utils.setText(Utils.FONT_PLAIN, Utils.INPUT_FG, "<html><body style='width: 200px;'> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</body></html>");
      textBox.add(b);
      textBox.add(label);
    }


    private CustomPanel createMemberPanel() {
        final Dimension size = new Dimension(100, 100);


        CustomPanel member = new CustomPanel();
        member.setPreferredSize(size);
        member.setRadius(100);
        member.setBackground(Color.WHITE);

        return member;
    }

    private void Panel1(JPanel a) {

    }

    /* private void aboutUs(JPanel a) {

        JLabel header = Utils.setText(Utils.FONT_BOLD, Utils.INPUT_FG, "ABOUT US");
        gbc.gridy = 0;
        gbc.gridx = 0;
        gbc.weighty = .5;
        gbc.weightx = 1;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.insets = new Insets(10, 0, 10, 0);
        a.add(header);

        CustomPanel member1 = createMemberPanel();
        gbc.gridy = 1;
        gbc.gridx = 0;
        gbc.weighty = .5;
        gbc.weightx = 1;
        gbc.anchor = GridBagConstraints.NORTH;
        a.add(member1);

        JLabel text1 = Utils.setText(Utils.FONT_PLAIN, Utils.INPUT_FG, "<html><div style='width: 400px;'>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div></html>");
        gbc.gridy = 2;
        gbc.gridx = 0;
        gbc.weighty = 0;
        gbc.weightx = 1;
        gbc.anchor = GridBagConstraints.NORTH;
        a.add(text1);

        JLabel text2 = Utils.setText(Utils.FONT_PLAIN, Utils.INPUT_FG, "<html><div style='width: 400px;'>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div></html>");
        gbc.gridy = 3;
        gbc.gridx = 0;
        gbc.weighty = 0;
        gbc.weightx = 1;
        gbc.anchor = GridBagConstraints.NORTH;
        a.add(text2, gbc);

        JLabel text3 = Utils.setText(Utils.FONT_PLAIN, Utils.INPUT_FG, "<html><div style='width: 400px;'>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div></html>");
        gbc.gridy = 4;
        gbc.gridx = 0;
        gbc.weighty = 0;
        gbc.weightx = 1;
        gbc.anchor = GridBagConstraints.NORTH;
        a.add(text3, gbc);

    }
    */



    public static void navBar(JPanel a) {
        CustomTextField navBar = new CustomTextField(0, 30);
        navBar.setPreferredSize(new Dimension(300, 30));
        navBar.setFont(Utils.FONT_PLAIN);

        gbc.gridy = 0;
        gbc.gridx = 0;
        gbc.insets = new Insets(0, 10, 0, 10);
        a.add(navBar, gbc);
    }
}

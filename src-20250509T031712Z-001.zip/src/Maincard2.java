import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;


///  this is the page of the shopping catalog
/// this should be the main priority of this application
///  refer to {@link DBOperations} to have a basic idea on how to start working with creating Databases

public class Maincard2 extends JPanel {
    private static GridBagConstraints gbc = new GridBagConstraints();
    private JPanel productPanel;

    Maincard2() {
        setLayout(new BoxLayout(this, 1));
        setBackground(Utils.BG2_COLOR);
        JPanel topBar = new JPanel();
        topBar.setPreferredSize(new Dimension(200, 60));
        topBar.setLayout(new GridBagLayout());
        topBar.setBackground(Utils.BG_COLOR);
        add(topBar);


        productPanel = this.createShoppingPanel();
        JScrollPane scrollable = new JScrollPane(this.productPanel);
        scrollable.setBorder(BorderFactory.createEmptyBorder());
        Utils.product = productPanel;
        add(scrollable);
        navBar(topBar);


        JButton btnSearch;
        topBar.add(btnSearch = new JButton("Search"));
        JButton btnAdd;
        topBar.add(btnAdd = new JButton("Add"));
        new ProductEditor(btnSearch, Action.SEARCH);
        new ProductEditor(btnAdd, Action.ADD);
    }

    public static void navBar(JPanel a) {
        CustomTextField navBar = new CustomTextField(0, 30);
        navBar.setPreferredSize(new Dimension(300, 30));
        navBar.setFont(Utils.FONT_PLAIN);
        gbc.gridy = 0;
        gbc.gridx = 0;
        gbc.insets = new Insets(0, 10, 0, 10);
        a.add(navBar, gbc);
    }

    private JPanel createShoppingPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(Utils.BG2_COLOR);
        panel.setPreferredSize(new Dimension(200, 600));
        panel.setLayout(new FlowLayout(0, 20, 20));
        return panel;
    }
}

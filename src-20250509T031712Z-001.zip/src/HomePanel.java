import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomePanel extends JPanel {
    private static final int SIDEBAR_WIDTH = 250;

    public HomePanel(Window parent) {
        setLayout(new BorderLayout());

        // Sidebar panel
        JPanel sidebar = new JPanel();
        sidebar.setPreferredSize(new Dimension(SIDEBAR_WIDTH, 0));
        sidebar.setBackground(Utils.BG2_COLOR);
        sidebar.setLayout(new BorderLayout());

        // Profile panel
        JPanel profilePanel = new JPanel(new GridBagLayout());
        profilePanel.setPreferredSize(new Dimension(SIDEBAR_WIDTH, 200));
        profilePanel.setBackground(new Color(35, 35, 35));

        // Profile circle (CustomPanel)
        CustomPanel profile = new CustomPanel();
        profile.setPreferredSize(new Dimension(100, 100)); // must be square
        profile.setBackground(Color.WHITE);
        profile.setRadius(100);

        // GridBag for profile panel layout
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(10, 0, 5, 0);
        profilePanel.add(profile, gbc);

        // Username label
        JLabel usernameLabel = new JLabel("Charles Kevin"); // Replace with dynamic value if needed
        usernameLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        usernameLabel.setFont(new Font("FONT_BOLD", Font.BOLD, 16));
        usernameLabel.setForeground(Color.WHITE); // Make sure it’s visible on dark background
        gbc.gridy = 1;
        gbc.insets = new Insets(0, 0, 10, 0);
        profilePanel.add(usernameLabel, gbc);

        // Add profilePanel to sidebar
        sidebar.add(profilePanel, BorderLayout.NORTH);

        // Actions panel (for buttons)
        JPanel actionsPanel = new JPanel();
        actionsPanel.setBackground(new Color(30, 30, 30));
        actionsPanel.setLayout(new BoxLayout(actionsPanel, BoxLayout.Y_AXIS));
        // Vertical layout for buttons

        // Add actionsPanel to sidebar
        sidebar.add(actionsPanel, BorderLayout.CENTER);

        // --- Add logout button at the bottom ---
        JButton logoutBtn = new JButton("Log Out");
        logoutBtn.setFocusPainted(false);
        logoutBtn.setFont(Utils.FONT_PLAIN);
        logoutBtn.setBackground(new Color(200, 70, 70));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        logoutBtn.addActionListener(e -> parent.showCard("Login"));

        // Bottom panel for logout button
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setBackground(new Color(25, 25, 25));
        bottomPanel.add(logoutBtn);

        sidebar.add(bottomPanel, BorderLayout.SOUTH);

        // Add sidebar to left side
        add(sidebar, BorderLayout.WEST);

        // Main content panel
        JPanel mainContent = new JPanel();
        mainContent.setBackground(new Color(50, 50, 60));
        mainContent.setLayout(new CardLayout());
        add(mainContent, BorderLayout.CENTER);

        Maincard1 maincard1 = new Maincard1();
        Maincard2 maincard2 = new Maincard2();
        Maincard3 maincard3 = new Maincard3();
        Maincard4 maincard4 = new Maincard4();

        mainContent.add(maincard1, "card1");
        mainContent.add(maincard2, "card2");
        mainContent.add(maincard3, "card3");
        mainContent.add(maincard4, "card4");


        sidebarActions(actionsPanel, maincard1, maincard2, maincard3, mainContent);

    }

    private void sidebarActions(JPanel actionsPanel, JPanel a, JPanel b, JPanel c, JPanel main) {

        JButton Home = new JButton("\uD83C\uDFE0 Home");
        Home.setPreferredSize(new Dimension(400, 50));
        Home.setFont(new Font("Futura", Font.BOLD, 16));
        Home.setForeground(Color.WHITE);
        Home.setOpaque(false);
        Home.setContentAreaFilled(false);
        Home.setBorderPainted(false);
        actionsPanel.add(Home);

        CardLayout cl = (CardLayout) main.getLayout();
        cl.show(main, "card1");
        Home.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cl.show(main, "card1");
            }
        });


        JButton Shop = new JButton("\uD83D\uDED2 Shop");
        Shop.setFont(new Font("Futura", Font.BOLD, 16));
        Shop.setForeground(Color.WHITE);
        Shop.setOpaque(false);
        Shop.setContentAreaFilled(false);
        Shop.setBorderPainted(false);
        actionsPanel.add(Shop);

        Shop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cl.show(main, "card2");
            }
        });


        JButton Transactions = new JButton("\uD83E\uDDFE View Current Order");
        Transactions.setFont(new Font("Futura", Font.BOLD, 16));
        Transactions.setForeground(Color.WHITE);
        Transactions.setOpaque(false);
        Transactions.setContentAreaFilled(false);
        Transactions.setBorderPainted(false);
        actionsPanel.add(Transactions);

        Transactions.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cl.show(main, "card3");
            }
        });


        JButton Faq = new JButton("\uD83D\uDC4D About us");
        Faq.setFont(new Font("Futura", Font.BOLD, 16));
        Faq.setForeground(Color.WHITE);
        Faq.setOpaque(false);
        Faq.setContentAreaFilled(false);
        Faq.setBorderPainted(false);
        actionsPanel.add(Faq);

        Faq.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cl.show(main, "card4");
            }
        });
    }


}
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/// this is the object that is responsible for product
/// about to be displayed in the shopping catalog

public class ProductObjects extends CustomPanel {
    private long id;
    private String name;
    private int quantity;
    private double price;


    private final Dimension size = new Dimension(200, 250);

    ProductObjects(long id, String name, int quantity, double price) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.price = price;


        createPanel(this, name, quantity, price);
    }

    public long getId() {
        return id;
    }

    private void createPanel(JPanel a, String name, int quantity, double price) {
        CustomPanel panel = new CustomPanel();
        setRadius(20);
        setPreferredSize(size);
        setMaximumSize(size);
        setBackground(Utils.BG2_COLOR);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));


        //Image panel ni diri
        CustomPanel b = new CustomPanel();
        b.setRadius(10);
        b.setPreferredSize(new Dimension(130, 180));
        b.setBackground(Color.WHITE);




        add(b);

        //Description about sa product
        JPanel c = new JPanel();
        c.setBackground(Utils.BG2_COLOR);
        c.setMaximumSize(new Dimension(100, 1000));
        c.setPreferredSize(new Dimension(100, 100));

        c.setLayout(new BoxLayout(c, BoxLayout.Y_AXIS));
        add(c);

        c.add(Utils.setText(Utils.FONT_PLAIN, Utils.INPUT_FG, name));
        c.add(Utils.setText(Utils.FONT_PLAIN, Utils.INPUT_FG, "Quantity: " + Integer.toString(quantity)));
        c.add(Utils.setText(Utils.FONT_PLAIN, Utils.INPUT_FG,"$" + Double.toString(price)));

        JButton update = new JButton("UPDATE");
        JButton delete = new JButton("DELETE");

        /**
         * Assigns the button to the class of ProductEditor to handle the action taken by the User
         * {@link ProductEditor}
         */

        new ProductEditor(update, Action.EDIT, id);
        new ProductEditor(delete, Action.DELETE, id);

        add(update);
        add(delete);
    }
}

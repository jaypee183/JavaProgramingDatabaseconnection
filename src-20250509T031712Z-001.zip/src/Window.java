import javax.swing.*;
import java.awt.*;

/// a JFrame subclass, that is responsible for creating a new window

public class Window extends JFrame {
    private final CardLayout cl = new CardLayout();
    private final JPanel cardPanel = new JPanel(cl);

    public Window(String title) {
        super(title);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        cardPanel.add(new LoginPanel(this), "Login");
        cardPanel.add(new HomePanel(this), "Home");
        add(cardPanel);
        setVisible(true);
    }

    public void showCard(String name) {
        cl.show(cardPanel, name);
    }
}


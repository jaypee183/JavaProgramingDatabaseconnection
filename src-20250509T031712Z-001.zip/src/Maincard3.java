import javax.swing.*;
import java.awt.*;



///  this is the page of the transaction list

public class Maincard3 extends JPanel {
    private CardLayout cardLayout;
    private JPanel cardPanel;


    Maincard3() {
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        ReceiptView receiptView = new ReceiptView();
        cardPanel.add(receiptView, "receipt");


        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Utils.BG2_COLOR);

        add(Utils.topBar());
        JScrollPane transactionPanel = Utils.mainContent(200, 1200);
        add(transactionPanel);
        JPanel content = (JPanel) transactionPanel.getViewport().getView();
        content.add(header());
        JPanel tList = transanctionList();
        content.add(tList);
        content.add(orderButtons());
        content.add(cardPanel);

        /* // Main layout is now CardLayout to switch entire views
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        // Order screen
        JPanel orderView = new JPanel();
        orderView.setLayout(new BoxLayout(orderView, BoxLayout.Y_AXIS));
        orderView.setBackground(Utils.BG2_COLOR);
        orderView.add(Utils.topBar());

        JScrollPane transactionPanel = Utils.mainContent(200, 1200);
        JPanel content = (JPanel) transactionPanel.getViewport().getView();
        content.add(header());
        content.add(transanctionList());
        content.add(orderButtons());  // buttons control switching

        orderView.add(transactionPanel);

        // Receipt screen
        ReceiptView receiptView = new ReceiptView();

        // Add both views to cardPanel
        cardPanel.add(orderView, "order");
        cardPanel.add(receiptView, "receipt");

        // Use cardPanel as the main panel's layout
        setLayout(new BorderLayout());
        add(cardPanel, BorderLayout.CENTER);
        */

    }

    private CustomPanel header() {
        CustomPanel head = new CustomPanel();
        head.setPreferredSize(new Dimension(1000, 100));
        head.setRadius(20);
        head.setBackground(Color.BLACK);
        head.setLayout(new GridBagLayout());

        JLabel number = Utils.setText(Utils.FONT_BOLD, Utils.INPUT_FG, "No.");
        JLabel image = Utils.setText(Utils.FONT_BOLD, Utils.INPUT_FG, "Image");
        JLabel name = Utils.setText(Utils.FONT_BOLD, Utils.INPUT_FG, "Name");
        JLabel quantity = Utils.setText(Utils.FONT_BOLD, Utils.INPUT_FG, "Quantity");
        JLabel price = Utils.setText(Utils.FONT_BOLD, Utils.INPUT_FG, "Price");

        GridBagConstraints gbc = new GridBagConstraints();

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weighty = 0;
        gbc.weightx = 1;
        gbc.insets = new Insets(0, 60, 0,0);
        gbc.anchor = GridBagConstraints.WEST;
        head.add(number, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;
        gbc.insets = new Insets(0, 0, 0, 0);
        head.add(image, gbc);

        gbc.gridx = 2;
        gbc.weightx = 2;
        head.add(name, gbc);

        gbc.gridx = 3;
        gbc.weightx = 1;
        head.add(quantity, gbc);

        gbc.gridx = 4;
        gbc.weightx = 1;
        head.add(price, gbc);


        return head;
    }

    private CustomPanel transanctionList() {
        CustomPanel tList = new CustomPanel();
        tList.setPreferredSize(new Dimension(1000, 600));
        tList.setRadius(20);
        tList.setBackground(Color.WHITE);
        tList.setLayout(new GridBagLayout());

        return tList;
    }

    private JPanel orderButtons() {
        JPanel orderButtons = new JPanel();
        orderButtons.setPreferredSize(new Dimension(500, 200));
        orderButtons.setBackground(Utils.BG2_COLOR);
        orderButtons.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));

        JButton purchaseOrder = new JButton("Confirm Order");
        purchaseOrder.setPreferredSize(new Dimension(150, 50));
        JButton cancelOrder = new JButton("Cancel Order");
        cancelOrder.setPreferredSize(new Dimension(150, 50));

        orderButtons.add(purchaseOrder);
        orderButtons.add(cancelOrder);

        purchaseOrder.addActionListener(e ->
        {
            cardLayout.show(cardPanel, "receipt");
        });


        return orderButtons;


    }

}

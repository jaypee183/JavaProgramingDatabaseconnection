import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;


/** just like the {@link AddWindow}, this also pop-ups when the edit button is clicked
 * this is just the workaround dealing with pop-up panels.
 * we may need a logic for this soon
 */


public final class EditWindow extends JFrame {
    static GridBagConstraints gbc = new GridBagConstraints();

    private static String productName;
    private static JLabel productIcon;
    private static double productPrice;
    private static int productQuantity;

    EditWindow() {
        setSize(500, 500);
        setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
        setVisible(true);
        setResizable(false);
        setBackground(Utils.BG_COLOR);
    }

    private void addForm(JFrame frame) {

        CustomPanel imagePanel = new CustomPanel();
        imagePanel.setRadius(20);
        imagePanel.setPreferredSize(new Dimension(250, 250));
        imagePanel.setMaximumSize(new Dimension(250, 250));
        imagePanel.setBackground(Color.WHITE);
        imagePanel.setAlpha(0.3F);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        gbc.weighty = 1;
        gbc.anchor = GridBagConstraints.NORTH;

        add(imagePanel, gbc);

        JButton jButton = new JButton("Upload");
        jButton.setBackground(Color.WHITE);
        jButton.setFocusPainted(false);

        jButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(null);
            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();

                try {
                    BufferedImage img = ImageIO.read(selectedFile);
                    ImageIcon icon = new ImageIcon(img.getScaledInstance(200, 200, Image.SCALE_SMOOTH));
                    JLabel imageLabel = new JLabel(icon);

                    imagePanel.removeAll(); // Optional: clear previous image
                    imagePanel.add(imageLabel);
                    imagePanel.revalidate();
                    imagePanel.repaint();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        gbc.gridy = 1;
        gbc.gridx = 0;
        gbc.weightx = 0;
        gbc.weighty = 15;
        add(jButton, gbc);



        gbc.gridy++;
        gbc.weightx = 1;
        gbc.weighty = 60;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(0, 40, 0, 40);
        JPanel b = new JPanel();
        b.setLayout(new GridLayout(6, 0));
        b.setBackground(Utils.BG_COLOR);
        add(b, gbc);

        b.add(Utils.setText(Utils.FONT_PLAIN, Utils.INPUT_FG, "NAME: "));

        CustomTextField name = new CustomTextField(0 , 20);
        b.add(name);

        b.add(Utils.setText(Utils.FONT_PLAIN, Utils.INPUT_FG, "PRICE: "));
        CustomTextField price = new CustomTextField(0 , 20);
        b.add(price);

        b.add(Utils.setText(Utils.FONT_PLAIN, Utils.INPUT_FG, "QUANTITY: "));
        CustomTextField quantity = new CustomTextField(0 , 20);
        b.add(quantity);

        GridBagConstraints z = new GridBagConstraints();

        JPanel c = new JPanel();
        c.setLayout(new GridBagLayout());
        c.setBackground(Utils.BG_COLOR);
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.weighty = 1;
        gbc.weightx = 1;
        gbc.insets = new Insets(10, 40, 10, 40);

        add(c, gbc);

        JButton submit = new JButton("Submit");
        submit.setFocusPainted(false);
        submit.setBackground(Color.WHITE);
        z.gridx = 0;
        z.gridy = 0;
        z.weightx = 0;
        z.anchor = GridBagConstraints.CENTER;
        c.add(submit, z);

        JButton cancel = new JButton("Cancel");
        cancel.setFocusPainted(false);
        cancel.setBackground(Color.WHITE);
        z.gridx = 1;
        z.gridy = 0;
        z.insets = new Insets(0, 10, 0, 10);
        c.add(cancel, z);

        submit.addActionListener(e -> {
            if (name.getText().isEmpty() || price.getText().isEmpty() || quantity.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter data on each of these fields", "INPUT ERROR!", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                productName = name.getText();
                productPrice = Double.parseDouble(price.getText());
                productQuantity = Integer.parseInt(quantity.getText());
                System.out.println(productName + " " + productPrice + " " + productQuantity);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "ERROR! the fields of Price and Data must be in number", "ERROR", JOptionPane.ERROR_MESSAGE);
                price.setText("");
                quantity.setText("");
                return;
            }

            DBOperations.addProcess(productName, productPrice, productQuantity);

            dispose();
        });
        cancel.addActionListener(e -> {
            dispose();
        });

    }
}
